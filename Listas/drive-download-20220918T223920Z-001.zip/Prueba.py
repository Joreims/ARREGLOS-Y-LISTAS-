import Clases as c

lista = c.ListadoEst

est = c.Estudiante("11", "HArry", "Bodan", "ISI", True)

lista.agregarElemento(est)

print(lista)